#include <stdio.h>

int main(){
    /*
    1) char - 1 Byte ou seja, 8 bits
    2) int - 2 Bytes (32768 até - 32767)
    3) float - 4 Bytes 
    4) void - vazio
    5) double - 8 Bytes

    
    */
}